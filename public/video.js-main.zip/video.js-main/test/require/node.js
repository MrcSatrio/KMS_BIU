/* eslint-disable no-console */
try {
  require('../../');
} catch (e) {
  console.error(e);
  process.exit(1);
}

process.exit(0);
