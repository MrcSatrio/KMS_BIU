import videojs from './video';
import 'videojs-contrib-quality-levels';
import '@videojs/http-streaming';
export default videojs;
